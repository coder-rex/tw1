module.exports = {
  database: 'mongodb://root:abc123@ds133221.mlab.com:33221/arashtwitter',
  secret: "hahahaha88888"

}
